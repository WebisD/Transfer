import torch
import pandas as pd
from PIL import Image, ImageDraw
import matplotlib.pyplot as plt
from cosypose.config import LOCAL_DATA_DIR
import os

# GPU setting (optional)
os.environ['CUDA_VISIBLE_DEVICES'] = '0'

# Paths and loading
result_id = 'bop-pbr--46860/dataset=baja'
detectorzada = "/home/fernando/Documents/Webis/6D/cosypose/local_data/experiments/detector-bop-baja-pbr--142662/dataset=baja.bop19/epoch=270/results.pth.tar"
results_d = torch.load(detectorzada)

# Get detections
detections = results_d['predictions']['model/detections']
bboxes = detections.bboxes
infos = detections.infos

# Filter for scene_id=0 and view_id=398
target_scene_id = 0
target_view_id = 8
filtered_infos = infos[(infos.scene_id == target_scene_id) & (infos.view_id == target_view_id)]

from PIL import ImageFont
font = ImageFont.truetype("DejaVuSans-Bold.ttf", 20)  # Adjust path or size if needed

if filtered_infos.empty:
    print("No detections found for the given scene/view ID.")
else:
    # Load image
    image_path = f"/home/fernando/Documents/Webis/6D/cosypose/local_data/bop_datasets/baja/test/{target_scene_id:06d}/rgb/{target_view_id:06d}.jpg"
    image = Image.open(image_path).convert("RGB")
    draw = ImageDraw.Draw(image)

    # Draw all bboxes for filtered detections
    for _, row in filtered_infos.iterrows():
        bbox = bboxes[row.batch_pred_id].tolist()
        x1, y1, x2, y2 = bbox
        draw.rectangle([x1, y1, x2, y2], outline="red", width=2)
        draw.text((x1, y1 - 25), f"{row.label} ({row.score:.2f})", fill="red", font=font)

    # Show image
    plt.figure(figsize=(10, 10))
    plt.imshow(image)
    plt.axis("off")
    plt.title(f"Detections for Scene {target_scene_id}, View {target_view_id}")
    plt.show()
