import argparse
from pathlib import Path

import cv2
import torch.utils.data
import numpy as np

from .. import utils
from ..data import obj
from ..data.config import config
from ..data import instance
from ..data import detector_crops
from ..data.renderer import ObjCoordRenderer
from ..surface_embedding import SurfaceEmbeddingModel
from .. import pose_est
from .. import pose_refine


def estimate_pose():
        print()
        with utils.timer('pnp ransac'):
            print("BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB")
            print('=========down_sample_scale=======')
            print(down_sample_scale)
            print('=======Verts obj_pts=========')
            print(verts)
            print('========Normals obj_normals========')
            print(normals)
            print('======Keys Vert obj_keys==========')
            print(keys_verts)
            print('=======Diameter obj_diameter=========')
            print(obj_.diameter)
            print('========KCrop K========')
            print(K_crop)
            print('================')
            R, t, scores, mask_scores, coord_scores, dist_2d, size_mask, normals_mask = pose_est.estimate_pose(
                mask_lgts=mask_lgts, query_img=query_img, down_sample_scale=down_sample_scale,
                obj_pts=verts, obj_normals=normals, obj_keys=keys_verts,
                obj_diameter=obj_.diameter, K=K_crop,
            )
        if not len(scores):
            print('no pose')
            return None
        else:
            R, t, scores, mask_scores, coord_scores = [a.cpu().numpy() for a in
                                                       (R, t, scores, mask_scores, coord_scores)]
            best_pose_idx = np.argmax(scores)
            R_, t_ = R[best_pose_idx], t[best_pose_idx, :, None]
            debug_pose_hypothesis(R_, t_)
            return R_, t_



parser = argparse.ArgumentParser()
parser.add_argument('model_path')
parser.add_argument('--real', action='store_true')
parser.add_argument('--detection', action='store_true')
parser.add_argument('--i', type=int, default=0)
parser.add_argument('--device', default='cuda:0')

args = parser.parse_args()
data_i = args.i
device = torch.device(args.device)
model_path = Path(args.model_path)

model = SurfaceEmbeddingModel.load_from_checkpoint(args.model_path)
model.eval()
model.freeze()
model.to(device)

dataset = model_path.name.split('-')[0]
real = args.real
detection = args.detection
root = Path('data/bop') / dataset
cfg = config[dataset]
res_crop = 224

objs, obj_ids = obj.load_objs(root / cfg.model_folder)
renderer = ObjCoordRenderer(objs, res_crop)
print(root, cfg.model_folder)
print(len(obj_ids), model.n_objs)
assert len(obj_ids) == model.n_objs
surface_samples, surface_sample_normals = utils.load_surface_samples(dataset, obj_ids)
print("AZAZAZZZZAZZAZAZA")
print(len(surface_samples))
print(surface_samples[0])
print("AZAZAZZZZAZZAZAZA")
auxs = model.get_infer_auxs(objs=objs, crop_res=res_crop, from_detections=detection)
dataset_args = dict(dataset_root=root, obj_ids=obj_ids, auxs=auxs, cfg=cfg)
if detection:
    assert args.real
    data = detector_crops.DetectorCropDataset(
        **dataset_args, detection_folder=Path(f'data/detection_results/{dataset}')
    )
else:
    data = instance.BopInstanceDataset(**dataset_args, pbr=not args.real, test=args.real)



inst = data[data_i]

# Extract RGB image and bounding box
rgb = inst['rgb'].copy()   # Make a copy to draw on
x1, y1, x2, y2 = inst['bbox']  # Bounding box format: [x1, y1, x2, y2]

# Draw bounding box
cv2.rectangle(rgb, (int(x1), int(y1)), (int(x2), int(y2)), color=(0, 255, 0), thickness=2)

# Display the image with bounding box
cv2.imshow("Projected Pose", rgb)
cv2.waitKey(0)
cv2.destroyAllWindows()