import torch
from surfemb.surface_embedding import SurfaceEmbeddingModel


#model = SurfaceEmbeddingModel.load_from_checkpoint( )
# Load state dict
#state_dict = torch.load('/home/webis/source/6D/surfemb/data/models/tudl-3js88k4j.compact.ckpt', map_location='cuda:0')
state_dict = torch.load('/home/webis/source/6D/cosypose/local_data/results/bop-baja-pbr-refiner--85617/checkpoint.pth.tar', map_location='cuda:0')
print(state_dict.keys())