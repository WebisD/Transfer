#!/usr/bin/env python3
import os
import sys
import subprocess
import shutil
import glob
import resource
import psutil

def print_section(title):
    """Print a section header."""
    print("\n" + "=" * 50)
    print(f" {title} ".center(50, "="))
    print("=" * 50 + "\n")

def check_ulimit():
    """Check and display current file descriptor limits."""
    print_section("File Descriptor Limits")
    soft, hard = resource.getrlimit(resource.RLIMIT_NOFILE)
    print(f"Current soft limit: {soft}")
    print(f"Current hard limit: {hard}")
    print(f"Current process is using: {len(psutil.Process().open_files())} file descriptors")
    
    # Check system-wide limits
    try:
        fs_max = int(open('/proc/sys/fs/file-max').read().strip())
        print(f"System-wide file max: {fs_max}")
    except:
        print("Could not read system-wide file max")
    
    return soft, hard

def increase_ulimit(new_limit=8192):
    """Try to increase the file descriptor limit for this process."""
    print_section("Increasing File Descriptor Limit")
    try:
        resource.setrlimit(resource.RLIMIT_NOFILE, (new_limit, new_limit))
        new_soft, new_hard = resource.getrlimit(resource.RLIMIT_NOFILE)
        print(f"New soft limit: {new_soft}")
        print(f"New hard limit: {new_hard}")
        return True
    except Exception as e:
        print(f"Failed to increase limit: {e}")
        print("You may need to run with sudo or adjust /etc/security/limits.conf")
        return False

def clean_temp_files():
    """Clean up temporary wandb files."""
    print_section("Cleaning Temporary Files")
    wandb_patterns = [
        '/tmp/tmp*wandb*',
        '/tmp/wandb-*'
    ]
    
    total_removed = 0
    for pattern in wandb_patterns:
        try:
            dirs = glob.glob(pattern)
            print(f"Found {len(dirs)} directories matching {pattern}")
            for d in dirs:
                try:
                    if os.path.isdir(d):
                        print(f"Removing {d}...")
                        shutil.rmtree(d)
                        total_removed += 1
                except Exception as e:
                    print(f"Error removing {d}: {e}")
        except Exception as e:
            print(f"Error processing pattern {pattern}: {e}")
    
    print(f"Successfully removed {total_removed} directories")

def find_open_files_by_program(program_name):
    """Find processes with the given name and how many files they have open."""
    print_section(f"Open Files by {program_name} Processes")
    try:
        cmd = f"pgrep -f {program_name}"
        result = subprocess.run(cmd, shell=True, text=True, stdout=subprocess.PIPE)
        pids = result.stdout.strip().split('\n')
        
        if not pids or (len(pids) == 1 and not pids[0]):
            print(f"No processes found matching '{program_name}'")
            return
        
        for pid in pids:
            if not pid:
                continue
            try:
                pid = int(pid)
                proc = psutil.Process(pid)
                files = proc.open_files()
                print(f"PID {pid} ({proc.name()}): {len(files)} open files")
                
                # Show a sample of open files
                if files:
                    print("Sample of open files:")
                    for f in files[:5]:
                        print(f"  - {f.path}")
                    if len(files) > 5:
                        print(f"  ... and {len(files)-5} more")
            except Exception as e:
                print(f"Error processing PID {pid}: {e}")
    except Exception as e:
        print(f"Error finding processes: {e}")

def generate_fix_recommendations():
    """Generate recommendations to fix the issue."""
    print_section("Recommendations")
    
    print("1. Add proper file handling in your code:")
    print("   - Use context managers (with statements) for all file operations")
    print("   - Example: with open('file.txt', 'r') as f: content = f.read()")
    print()
    
    print("2. For wandb specifically:")
    print("   - Ensure you call wandb.finish() after each run")
    print("   - Consider using wandb.init(mode='offline') during development")
    print("   - Limit the number of concurrent runs")
    print("   - Add proper error handling around wandb operations")
    print()
    
    print("3. System configuration:")
    print("   - Add to /etc/security/limits.conf (requires root):")
    print("     yourusername soft nofile 8192")
    print("     yourusername hard nofile 16384")
    print("   - Then log out and back in for changes to take effect")
    print()
    
    print("4. Monitor file usage:")
    print("   - Run 'lsof -p YOUR_PID | wc -l' to check open files for a process")
    print("   - Use 'watch -n 1 \"lsof | wc -l\"' to monitor overall open files")

def main():
    print_section("Too Many Open Files - Diagnostic Tool")
    
    # Check current limits
    soft, hard = check_ulimit()
    
    # Try to increase limits
    if soft < 4096:
        increase_ulimit()
    
    # Clean temporary files
    clean_temp_files()
    
    # Find processes with many open files
    find_open_files_by_program("python")
    
    # Check specifically for wandb processes
    find_open_files_by_program("wandb")
    
    # Generate recommendations
    generate_fix_recommendations()
    
    print_section("Diagnostic Complete")
    print("After implementing fixes, restart your application and")
    print("monitor for the 'Too many open files' error.")

if __name__ == "__main__":
    main()