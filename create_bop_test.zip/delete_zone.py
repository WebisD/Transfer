import os
import shutil

def delete_files_with_pattern(folder_path, pattern="Zone.Identifier"):
    for root, dirs, files in os.walk(folder_path):
        for file in files:
            if pattern in file:
                file_path = os.path.join(root, file)
                try:
                    os.remove(file_path)
                    print(f"Deleted: {file_path}")
                except Exception as e:
                    print(f"Failed to delete {file_path}: {e}")

if __name__ == "__main__":
    folder_to_scan = "/home/webis/source/6D/surfemb/data/bop/tudl/train_pbr"
    if os.path.exists(folder_to_scan):
        delete_files_with_pattern(folder_to_scan)
    else:
        print("The specified folder does not exist.")
