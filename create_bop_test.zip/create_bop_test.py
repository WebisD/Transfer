import os
import json

# Path to your dataset root directory
dataset_root = '/home/webis/source/6D/surfemb/data/bop/baja/'
test_dir = os.path.join(dataset_root, 'test')

# Output file path
output_path = os.path.join(dataset_root, 'test_targets_bop19.json')

targets = []

# Loop through each scene folder (000000 to 000004)
for scene_id in range(0, 5):
    scene_folder = os.path.join(test_dir, f'{scene_id:06d}')
    gt_path = os.path.join(scene_folder, 'scene_gt.json')

    if not os.path.exists(gt_path):
        print(f"⚠️  scene_gt.json not found in {scene_folder}")
        continue

    with open(gt_path, 'r') as f:
        scene_gt = json.load(f)

    for im_id_str, gt_entries in scene_gt.items():
        im_id = int(im_id_str)
        obj_counts = {}

        for gt in gt_entries:
            obj_id = gt['obj_id']
            obj_counts[obj_id] = obj_counts.get(obj_id, 0) + 1

        for obj_id, inst_count in obj_counts.items():
            # Insert keys in specific order
            targets.append({
                "im_id": im_id,
                "inst_count": inst_count,
                "obj_id": obj_id,
                "scene_id": scene_id
            })

# Save it with compact JSON formatting (no indentation)
with open(output_path, 'w') as f:
    # First line of the file should be an opening bracket
    f.write('[\n')
    
    # Write each entry on its own line with compact formatting
    for i, target in enumerate(targets):
        line = f'  {{"im_id": {target["im_id"]}, "inst_count": {target["inst_count"]}, "obj_id": {target["obj_id"]}, "scene_id": {target["scene_id"]}}}'
        
        # Add comma for all but the last entry
        if i < len(targets) - 1:
            line += ','
        
        f.write(line + '\n')
    
    # Close the JSON array
    f.write(']\n')

print(f"✅ test_targets_bop19.json saved with {len(targets)} entries.")