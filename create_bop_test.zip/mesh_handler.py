print("oi")
import pymeshlab

print("oi")
ms = pymeshlab.MeshSet()

#print(dir(ms))
#print([f for f in dir(ms) if "manifold" in f.lower()])
print("oi")
ms.load_new_mesh(str("C:/Users/wpereira/Documents/6D/surfemb/data/bop/baja/models/obj_000001.ply"))
ms.repair_non_manifold_edges_by_removing_faces()
print("oi")